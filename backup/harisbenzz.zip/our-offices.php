<?php
	$page = "Our Offices";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/our-offices.cmp.php";  
	include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>