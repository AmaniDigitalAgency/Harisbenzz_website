<?php
	$page = "Our Team";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/our-team.cmp.php";  
	include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>