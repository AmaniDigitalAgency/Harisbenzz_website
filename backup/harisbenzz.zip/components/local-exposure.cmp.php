    <section class="work-style-three">
        <div class="container"> 
            <div class="lower-content">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12 work-column wow fadeInLeft" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="work-block-one">
                            <h4><a href="service-2.html#"> Print Advertising </a></h4>
                            <div class="count-text">01</div>
                            <div class="text">Picture that he had recently cut out of an illtrated magazine and housed in a nice, gilded frame It showed a lady fitted out with a further.</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 work-column wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="work-block-one">
                            <h4><a href="service-2.html#"> Direct Emails List </a></h4>
                            <div class="count-text">02</div>
                            <div class="text">Picture that he had recently cut out of an illtrated magazine and housed in a nice, gilded frame It showed a lady fitted out with a further.</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 work-column wow fadeInRight" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="work-block-one">
                            <h4><a href="service-2.html#">  Property Website </a></h4>
                            <div class="count-text">03</div>
                            <div class="text">Picture that he had recently cut out of an illtrated magazine and housed in a nice, gilded frame It showed a lady fitted out with a further.</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 work-column wow fadeInLeft" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="work-block-one">
                            <h4><a href="service-2.html#"> Uganda Mailer </a></h4>
                            <div class="count-text">04</div>
                            <div class="text">Picture that he had recently cut out of an illtrated magazine and housed in a nice, gilded frame It showed a lady fitted out with a further.</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 work-column wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="work-block-one">
                            <h4><a href="service-2.html#"> Twilight Photography </a></h4>
                            <div class="count-text">05</div>
                            <div class="text">Picture that he had recently cut out of an illtrated magazine and housed in a nice, gilded frame It showed a lady fitted out with a further.</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 work-column wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="work-block-one">
                            <h4><a href="service-2.html#"> Twilight Photography </a></h4>
                            <div class="count-text">05</div>
                            <div class="text">Picture that he had recently cut out of an illtrated magazine and housed in a nice, gilded frame It showed a lady fitted out with a further.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>