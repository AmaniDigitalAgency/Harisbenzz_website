    <section class="page-title centred" style="background-image: url(images/main-slider/breadcrumb.jpg); max-height: 270px;">
        <!----div class="rotate-text">Exterior & Interionr Design</div---->
        <div class="container">
            <div class="content-box">
                <h1><?php echo $page; ?> </h1>
            </div>
        </div>
    </section>