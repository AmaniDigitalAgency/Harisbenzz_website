   <section class="about-section pb-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-12 col-sm-12 title-column">
                    <div class="title-box sec-title bg-white p-5"> 
						<div class = "row">
							<div class = "col-md-6">
								<h1 style = "font-size: 72px;"> Haris <br><span> Benzz. </span></h1>
							</div>
						</div>
                        
						<div class="content-box"> 
							<div class="text"> Our work in the real estate field speaks for itself. With a lengthy experience coupled with our desire, ability and affinity for the provision of high end property management and maintenace services, we are the number one choice for those looking for a stress free real estate experience in Kampala and beyond. Our properties stand out for their strategic locations, exquisite build and incredible customer care. </div>

						<div class="text"> 
							Our work in the real estate field speaks for itself. With a lengthy experience coupled with our desire, ability and affinity for the provision of high end property management and maintenace services, we are the number one choice for those looking for a stress free real estate experience in Kampala and beyond. Our properties stand out for their strategic locations, exquisite build and incredible customer care.  </div>
							<a href="about.php" class = "btn line-button"> Read Our story </a>
						</div>
                    </div>
                </div> 
                <div class="col-lg-5 col-md-12 col-sm-12 image-column">
                    <figure class="image-box"><img src="images/resource/about-1.jpg" alt=""></figure> 
                </div>
            </div>
        </div>
    </section>