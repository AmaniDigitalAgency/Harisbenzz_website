    <section class="team-section team-page">
        <div class="container">
            <div class="sec-title">
                <span class="top-title"> Haris Benzz </span>
                <h1> Our <br><span>Team.</span></h1>
                <p>Many of our projects cannot be featured in this section due to the Security levels of the space.<br /> Maman's team is all background checked, and trained to provide the best product with the stri-<br />ctest deadlines and toughest of specifications.</p>
            </div>
            <div class="inner-content b bg-dark p-5">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-12 team-block wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="team-block-one line-overlay bg-white">
                            <div class="image-box">
                                <span class="line"></span>
                                <span class="line line-bottom"></span>
                                <figure class="image"><img src="images/resource/team-1.jpg" alt=""></figure>
                            </div>
                            <div class="lower-content">
                                <h3><a href="single-team.html">Marcus Web</a></h3> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 team-block wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="team-block-one line-overlay bg-white">
                            <div class="image-box">
                                <span class="line"></span>
                                <span class="line line-bottom"></span>
                                <figure class="image"><img src="images/resource/team-2.jpg" alt=""></figure>
                            </div>
                            <div class="lower-content">
                                <h3><a href="single-team.html">Taminm Alows</a></h3> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 team-block wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="team-block-one line-overlay bg-white">
                            <div class="image-box">
                                <span class="line"></span>
                                <span class="line line-bottom"></span>
                                <figure class="image"><img src="images/resource/team-3.jpg" alt=""></figure>
                            </div>
                            <div class="lower-content">
                                <h3><a href="single-team.html">Julio Marry</a></h3> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 team-block wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="team-block-one line-overlay bg-white">
                            <div class="image-box">
                                <span class="line"></span>
                                <span class="line line-bottom"></span>
                                <figure class="image"><img src="images/resource/team-4.jpg" alt=""></figure>
                            </div>
                            <div class="lower-content">
                                <h3><a href="single-team.html">Martin Marry</a></h3> 
                            </div>
                        </div>
                    </div>    
                </div>
            </div>
        </div>
    </section>