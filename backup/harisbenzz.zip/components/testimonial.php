    <section class="testimonial-section">
        <div class="container">
            <div class="sec-title centered">
                <div class="count-text">05 </div>	
                <span class="top-title"> Testimonials </span>
                <h1 style = "color: #FFFFFF;"> Client <br><span> Feedback.</span></h1>
            </div>
            <div class="two-item-carousel owl-carousel owl-theme">
                <div class="testimonial-block-one">
                    <div class="text">
                        <p>Our work in the real estate field speaks for itself. With a lengthy experience coupled with our desire, ability and affinity for the provision of high end property management and maintenace services, we are the number one choice for those looking for a stress free real estate experience in Kampala. </p>
                    </div>
                    <div class="author"> 
                        <div class="author-info">
                            <h5>Jane Smith</h5>
                            <span>CEO, InDesign</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-block-one">
                    <div class="text">
                        <p> Our work in the real estate field speaks for itself. With a lengthy experience coupled with our desire, ability and affinity for the provision of high end property management and maintenace services, we are the number one choice for those looking for a stress free real estate experience in Kampala. </p>
                    </div>
                    <div class="author"> 
                        <div class="author-info">
                            <h5>Mitchl Jhon</h5>
                            <span>CEO, InDesign</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>