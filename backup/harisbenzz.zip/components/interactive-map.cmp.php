   <section class="bg-white">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-7 col-md-12 col-sm-12 title-column px-5 m-5">
                    <div class="title-box sec-title"> 
                        <span class="top-title"> Select By Location </span>
                        <h1> Interactive <br><span> Map. </span></h1> 
                    </div>
                </div> 
				
                <div class="col-lg-12 col-md-12 col-sm-12">
				<div class="mapouter"><div class="gmap_canvas"><iframe width="1400" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=Kampala%20road&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a><br><style>.mapouter{position:relative;text-align:right;height:500px;width:100%;}</style> <style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:100%;}</style></div></div>
				
			</div>
			</div>
			</div> 
		</section>
		
   <section class="bg-white py-5">
        <div class="container">
            <div class="row"> 
				
                <div class="col-md-4 col-sm-12">
					<div class = "listing-list">
						<a href = "listing-details.php"> 1. 6716 Colgate Ave. - $4,700/mo.3 </a>
						<a href = "listing-details.php">2.  96. 2940 Neilson Way #105 - $4,500/mo.</a>
						<a href = "listing-details.php"> 3. 8500 Sunset Blvd. - $</a>
						<a href = "listing-details.php"> 4. 1550 N. El Centro Ave. -   </a>
						<a href = "listing-details.php"> 5. 1737 N. Las Palmas Ave. -  </a>
						<a href = "listing-details.php"> 6. 1 Bloor Street West - $  </a>
					</div> 
				</div>
                <div class="col-md-4 col-sm-12">
					<div class = "listing-list">
						<a href = "listing-details.php"> 1. 6716 Colgate Ave. - $4,700/mo.3 </a>
						<a href = "listing-details.php">2.  96. 2940 Neilson Way #105 - $4,500/mo.</a>
						<a href = "listing-details.php"> 3. 8500 Sunset Blvd. - $</a>
						<a href = "listing-details.php"> 4. 1550 N. El Centro Ave. -   </a>
						<a href = "listing-details.php"> 5. 1737 N. Las Palmas Ave. -  </a>
						<a href = "listing-details.php"> 6. 1 Bloor Street West - $  </a>
					</div> 
				</div>
                <div class="col-md-4 col-sm-12">
					<div class = "listing-list">
						<a href = "listing-details.php"> 1. 6716 Colgate Ave. - $4,700/mo.3 </a>
						<a href = "listing-details.php">2.  96. 2940 Neilson Way #105 - $4,500/mo.</a>
						<a href = "listing-details.php"> 3. 8500 Sunset Blvd. - $</a>
						<a href = "listing-details.php"> 4. 1550 N. El Centro Ave. -   </a>
						<a href = "listing-details.php"> 5. 1737 N. Las Palmas Ave. -  </a>
						<a href = "listing-details.php"> 6. 1 Bloor Street West - $  </a>
					</div> 
				</div>
			</div>
			</div> 
		</section>