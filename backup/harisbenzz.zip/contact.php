<?php
	$page = "Contact Us";  
	include "header.php"; 
	include "components/breadcrumb.php";  
	include "components/contact.cmp.php";
?> 
 
	
<?php
	include "footer.php";
?>