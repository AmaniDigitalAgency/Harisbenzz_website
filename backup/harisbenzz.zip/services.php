<?php
	$page = "Services";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/services.php"; 
	include "components/counter.php";
	include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>