<?php
	$page = " About Us";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/about.php"; 
	include "components/counter.php";
	include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>