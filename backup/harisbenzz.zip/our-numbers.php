<?php
	$page = "Our Numbers";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/our-numbers.cmp.php";  
	include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>