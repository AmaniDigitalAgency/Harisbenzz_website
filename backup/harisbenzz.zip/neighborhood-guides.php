<?php
	$page = "Neigbourhood Guides";  
	include "header.php"; 
	include "components/breadcrumb.php";  
	include "components/interactive-map.cmp.php";  
?> 
  
<?php

	include "footer.php";
?>