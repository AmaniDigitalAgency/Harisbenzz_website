<?php
	$page = "Local Exposure";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/local-exposure.cmp.php";  
	include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>