<?php
	$page = "Clients";  
	include "header.php"; 
	include "components/breadcrumb.php";  
	include "components/testimonial.php";
	include "components/counter.php";
?> 
 
	
<?php
	include "footer.php";
?>