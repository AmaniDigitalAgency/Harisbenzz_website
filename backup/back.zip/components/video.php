    <section class="video-style-two centred" style="background-image: url(images/background/video-bg.jpg);" id = "video">
        <div class="parallax-scene parallax-scene-2 anim-icons">
            <span data-depth="0.40" class="parallax-layer icon icon-1"></span>
            <span data-depth="0.50" class="parallax-layer icon icon-2"></span>
            <span data-depth="0.30" class="parallax-layer icon icon-3"></span>
            <span data-depth="0.40" class="parallax-layer icon icon-4"></span>
            <span data-depth="0.50" class="parallax-layer icon icon-5"></span>
            <span data-depth="0.30" class="parallax-layer icon icon-6"></span>
        </div>
        <div class="container">
            <div class="inner-content">
                <span class="top-text"> Video Tour </span> 
                <h1> MAKING DREAMS A REALITY </h1>
                <a href="javascript:void(0)" class="video-link lightbox-image" data-caption=""><i class="flaticon-arrow"></i></a>
            </div>
        </div>
    </section>