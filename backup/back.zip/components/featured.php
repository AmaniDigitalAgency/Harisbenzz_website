    <section class="service-style-two alternate-2">
        <div class="container">
            <div class="inner-content">
               
				
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block wow fadeInLeft" data-wow-delay="00ms" data-wow-duration="1000ms"> 						
						<div class="sec-title pt-5"> 
							<h1 class = "mt-5"> Featured <br><span>Listings  </span></h1>
							<a href= "listings.php" class = "btn line-button"> See ALl properties </a>
						</div>
                    </div>
					
<?php getalllistings("listings");?> 

                    <div class="col-lg-4 col-md-6 col-sm-12 service-block wow fadeInLeft" data-wow-delay="00ms" data-wow-duration="1800ms">
                        <div class="px-5"> 
							<a href= "interactive-map.php" class = "btn line-button"> Interactive Map  </a>
							<a href= "search.php" class = "btn line-button"> Property Search </a>
							<a href= "listings.php" class = "btn line-button"> Featured Properties </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>