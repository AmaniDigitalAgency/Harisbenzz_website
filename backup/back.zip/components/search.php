    <section class="contact-info-section style-two">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-12 col-md-12 content-column">
                    <div class="sec-title pt-5"> 
							<h1 class = "mt-5"> Active <br><span>Listings  </span></h1> 
						</div>
                </div>
                <div class="col-xl-8 col-lg-12 col-md-12 form-column">
                    <div class="contact-form-area bg-image">
							<h2 class = "mb-5"> Search <span> Our Listings  </span></h2>
                        <form method="post" action="#" id="contact-form"> 
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                   <div class="slidecontainer">
									  <input type="range" min="1" max="100" value="50" class="slider" id="myRange">
									</div>
									<span  style = "color: #FFFFFF;"> USD</span>  <span id = "demo" style = "color: #FFFFFF;"></span>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                    <select class = "form-control" name = "property_location"> 
										<option> Min Beds </option>
										<option> 3 </option>
										<option> 2 </option> 
										<option> 1 </option>
									</select>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                    <select class = "form-control" name = "property_location">
										<option> Min Baths </option>
										<option> 3 </option>
										<option> 2 </option>
										<option> 1 </option>
									</select>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                    <select class = "form-control" name = "property_location">
										<option> Buziga </option>
										<option> Buziga </option>
										<option> Buziga </option>
										<option> Buziga </option>
									</select>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                    <label class="custom-checkbox"> All Listings 
									  <input type="checkbox" checked="checked">
									  <span class="checkmark"></span>
									</label>
 
									<label class="custom-checkbox"> For Rent  
									  <input type="checkbox">
									  <span class="checkmark"></span>
									</label>
									<label class="custom-checkbox"> For Sale 
									  <input type="checkbox">
									  <span class="checkmark"></span>
									</label>
									<label class="custom-checkbox"> Land 
									  <input type="checkbox">
									  <span class="checkmark"></span>
									</label>
                                </div> 
								<div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                    <input type = "text"  class = "form-control"  placeholder = "Search Listing By Address">
                                </div>
								
                                <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn">
                                    <button type="submit" class = "btn line-button" name="submit-form">Submit Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>