   <section class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-12 col-sm-12 title-column">
                    <div class="title-box sec-title"> 
                        <span class="top-title">Our story</span>
                        <h1> Haris <br><span> Benzz. </span></h1>
											<div class="content-box"> 
                        <div class="text"> Our work in the real estate field speaks for itself. With a lengthy experience coupled with our desire, ability and affinity for the provision of high end property management and maintenace services, we are the number one choice for those looking for a stress free real estate experience in Kampala and beyond. Our properties stand out for their strategic locations, exquisite build and incredible customer care. </div>

					<div class="text"> 
						Our work in the real estate field speaks for itself. With a lengthy experience coupled with our desire, ability and affinity for the provision of high end property management and maintenace services, we are the number one choice for those looking for a stress free real estate experience in Kampala and beyond. Our properties stand out for their strategic locations, exquisite build and incredible customer care.  </div>
                        <a href="#" class = "line-button"> our story </a>
                    </div>
                    </div>
                </div> 
                <div class="col-lg-5 col-md-12 col-sm-12 image-column">
                    <figure class="image-box"><img src="images/background/video-bg.jpg" alt=""></figure>
					<div class = "contact-sidebar">
						<img src = "images/logo.png" class = "img-fluid mb-3" alt = "Logo" style = "float: center; object-fit: contain;">
						<p><i class = "fa fa-envelope"></i>  info@harisbenzz.com </p>
						<p><i class = "fa fa-map-marker"></i> Shop 112, Corner Road, Muyenga Road </p>
						<ul>
							<li class = "facebook"><i class = "fab fa-facebook"></i></li> 
							<li class = "facebook"><i class = "fab fa-twitter"></i></li> 
							<li class = "facebook"><i class = "fab fa-instagram"></i></li> 
							<li class = "facebook"><i class = "fab fa-linkedin"></i></li> 
							<li class = "facebook"><i class = "fab fa-pinterest"></i></li> 
						</ul>
					</div>
                </div>
            </div>
        </div>
    </section>