    <section class="sidebar-page-container blog-classic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12 col-sm-12 content-side">
<?php
	$i = 0;
	while ($i<3){
		
?>	
                    <div class="blog-classic-content bg-white">
                        <div class="news-block-one">
                            <figure class="image-box"><a href="#"><img src="images/resource/news-3.jpg" alt="" style = "height: 300px; object-fit: cover; "></a></figure>
                            <div class="lower-content"> 
                                <h4><a href="#"> French Montana Sells Home He Bought From Selena Gomez for $5 Million </a></h4>
                                <div class="text">
                                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. </p>
                                </div>
                                <a class = "line-button" href="#">REad More</a> 
                            </div>
                        </div>  
                    </div>	
<?php
	$i++;
	}
?>						
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">
                    <div class="sidebar bg-white">
                        <div class="sidebar-search sidebar-widget">
                            <div class="widget-content">
                                <div class="form-group">
                                    <form action="blog-classic-2.html#" method="post">
                                        <input type="search" name="search-field" placeholder="Type your search" required>
                                        <button type="submit"><i class="flaticon-magnifying-glass"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="sidebar-categories sidebar-widget">
                            <h3 class="sidebar-title">Categories</h3>
                            <div class="widget-content">
                                <ul class="list"> 
                                    <li><a href="#"> Television  <span>12</span></a></li>
                                    <li><a href="#"> Radio  <span>02</span></a></li>
                                    <li><a href="#"> Online Coverage  <span>02</span></a></li>
                                    <li><a href="#"> Print &amp; Magazines <span>10</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="sidebar-post sidebar-widget">
                            <h3 class="sidebar-title">Popular Post</h3>
                            <div class="widget-content">
                                <div class="post">
                                    <figure class="thumb"><a href="#"><img src="images/resource/history-4.jpg" style = "height: 100%;"  alt=""></a></figure>
                                    <span class="date"> Renovation </span>
                                    <h5><a href="#">Modern extension to brick house</a></h5>
                                </div>
                                <div class="post">
                                    <figure class="thumb"><a href="#"><img src="images/resource/history-4.jpg" style = "height: 100%;"  alt=""></a></figure>
                                    <span class="date"> Renovation </span>
                                    <h5><a href="#">Modern extension to brick house</a></h5>
                                </div>
                                <div class="post">
                                    <figure class="thumb"><a href="#"><img src="images/resource/history-4.jpg" style = "height: 100%;" alt=""></a></figure>
                                    <span class="date"> Renovation </span>
                                    <h5><a href="#">Modern extension to brick house</a></h5>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </section>