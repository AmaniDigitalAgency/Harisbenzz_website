				<div class="page-inner mt--5"> 
					<div class="row">
<?php
	include "components/listing-component.cmp.php";
?>
 
					</div>
				</div>  