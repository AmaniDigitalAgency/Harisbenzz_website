<?php
	$page = " Buy with Us";  
	include "header.php"; 
	include "components/breadcrumb.php"; 
	include "components/buy-with-us.php"; 
?> 
 
	
<?php
	include "footer.php";
?>