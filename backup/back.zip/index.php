<?php
	require('includes/config.php');
	include "header.php";
	include "components/slider.php";
	include "components/featured.php";
	include "components/video.php";
	include "components/about1.php";
	include "components/services.php";
	//include "components/counter.php";
	//include "components/testimonial.php";
?> 
 
	
<?php
	include "footer.php";
?>